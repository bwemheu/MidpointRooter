# MidpointRooter
Midpoint-rooting of large phylogenetic trees
