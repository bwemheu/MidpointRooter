midpoint.root2 = function(tree)
{
  require(phytools)

  # Define starting data
  node0 = length(tree$tip.label) + 1
  number_nodes = max(tree$edge[,2])
  edge_lenghts = data.frame(edge = c(tree$edge[,2], node0), length = c(tree$edge.length, 0))
  
  # Function to get ancestor nodes (to not rely on the function from phytools)
  get_ancestors = function(tree,node)
  {
    nodes = NULL
    repeat
    {
      node = tree$edge[,1][which(tree$edge[,2] == node)]
      if(length(node) == 0) break
      nodes = c(nodes, node)
    }
    return(nodes)
  }
  
  # Returns edge lengths between two nodes
  get_edge_length = function(edge_lenghts, nodes)
  {
    total_edge_length = 0
    for(node in nodes)
    {
      total_edge_length = total_edge_length + edge_lenghts$length[which(edge_lenghts$edge == node)]
    }
    return(total_edge_length)
  }
  
  # in oder to calclculate the correct edge length we need to remove every node the tools share
  outersect <- function(x, y)
  {
    sort(c(setdiff(x, y), setdiff(y, x)))
  }
  
  cat(c("Tree has", length(tree$tip.label), "tips and", number_nodes, "nodes\n"))

  max_node1 = NULL
  max_node_list = NULL
  max_edge_length = 0
  
  cat("Starting to find tip pair with maximum distance\n")
  node_list = list()
  for(n in 1:length(tree$tip.label))
  {
    nodes = c(n, get_ancestors(tree,n))
    node_list[[n]] = nodes
    edge_length = get_edge_length(edge_lenghts, nodes)
    if(edge_length >= max_edge_length)
    {
      max_node1 = n
      max_node_list = nodes
      max_edge_length = edge_length
    }
    if(n %% 100 == 0) cat(c("Round 1:", n, "nodes finished\n"))
  }

  max_node2 = NULL
  max_edge_length = 0
  for(n in 1:length(tree$tip.label))
  {
    nodes = node_list[[n]]
    edge_length = get_edge_length(edge_lenghts, outersect(x = nodes, y = node_list[[max_node1]]))
    if(edge_length > max_edge_length)
    {
      max_node2 = n
      max_edge_length = edge_length
    }
    if(n %% 100 == 0) cat(c("Round 2:", n, "nodes finished\n"))
  }
  print(c(max_node1, max_node2, max_edge_length))
  
  spp = tree$tip.label[c(max_node1, max_node2)]
  if(max_node1 > max_node2) spp = spp[2:1]
  
  cat("Max. pair:", spp, "\nStart rerooting tree\n")
  dd = max_edge_length
  print(dd)
  nn <- which(tree$tip.label == spp[2])
  print(nn)
  tree = reroot(tree, nn, tree$edge.length[which(tree$edge[, 2] == nn)])
  edge_lenghts = data.frame(edge = c(tree$edge[,2], node0), length = c(tree$edge.length, 0))
  max_node1 = which(tree$tip.label == spp[1])
  max_node2 = which(tree$tip.label == spp[2])

  aa = get_ancestors(tree,max_node1)
  print(aa)
  
  if(length(tree$tip.label) <= 1000)
  {
    Dx <- c(0, dist.nodes(tree)[which(tree$tip.label == spp[1]), aa])
    names(Dx)[1] <- which(tree$tip.label == spp[1])
    print(Dx)
  }
  
  D = 0
  for(i in aa)
  {
    j = outersect(x = c(get_ancestors(tree, i), i), y = c(get_ancestors(tree, max_node1), max_node1))
    D = c(D, get_edge_length(edge_lenghts, j))
  }
  names(D) = c(max_node1, aa)
  print(D)
  
  i = 0
  while (D[i + 1] < (dd/2)) i = i + 1
  tree <- reroot(tree, as.numeric(names(D)[i]), D[i + 1] - dd/2)
  return(tree)
}